declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_SUBSCRIPTION_COMMITMENTS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,622,'CREATE TABLE "OCI_SUBSCRIPTION_COMMITMENTS" ("SUBSCRIPTION_ID" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"SUBSCRIPTION_LINE_ID" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"COMMITMENT_TIME_START" TIMESTAMP(6),"COMMITMENT_TIME_END" TIMESTAMP(6),"COMMITMENT_QUANTITY" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","COMMITMENT_AVAILABLE_AMT" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","COMMITMENT_LINE_NET_AMT" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","COMMITMENT_FA_VALUE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
