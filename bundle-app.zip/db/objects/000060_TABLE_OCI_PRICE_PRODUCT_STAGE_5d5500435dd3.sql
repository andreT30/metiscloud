declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_PRICE_PRODUCT_STAGE' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,577,'CREATE GLOBAL TEMPORARY TABLE "OCI_PRICE_PRODUCT_STAGE" ("PART_NUMBER" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"DISPLAY_NAME" VARCHAR2(400 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"METRIC_NAME" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"SERVICE_CATEGORY" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"DESCRIPTION" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","PRODUCT_JSON" CLOB COLLATE "USING_NLS_COMP" NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" ON COMMIT DELETE ROWS LOB ("PRODUCT_JSON") STORE AS BASICFILE (ENABLE STORAGE IN ROW 4000 NOCACHE)');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
