declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='APP_EMAIL_ENDPOINT_CACHE' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,512,'CREATE TABLE "APP_EMAIL_ENDPOINT_CACHE" ("COMPARTMENT_OCID" VARCHAR2(255 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"SUBMISSION_ENDPOINT" VARCHAR2(2000 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"RETRIEVED_AT" TIMESTAMP(6) WITH TIME ZONE NOT NULL,"EXPIRES_AT" TIMESTAMP(6) WITH TIME ZONE NOT NULL,"INVALIDATED_AT" TIMESTAMP(6) WITH TIME ZONE,"LAST_STATUS_CODE" NUMBER,"LAST_ERROR_CATEGORY" VARCHAR2(40 CHAR) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
