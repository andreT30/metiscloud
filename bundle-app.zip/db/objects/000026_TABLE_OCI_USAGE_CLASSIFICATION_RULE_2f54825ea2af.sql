declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_USAGE_CLASSIFICATION_RULE' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,770,'CREATE TABLE "OCI_USAGE_CLASSIFICATION_RULE" ("RULE_CODE" VARCHAR2(80 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"DESCRIPTION_PATTERN" VARCHAR2(512 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"UNIT_PATTERN" VARCHAR2(512 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"NORMALIZATION_PATTERN" VARCHAR2(80 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"USAGE_CATEGORY" VARCHAR2(80 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"USAGE_SUBCATEGORY" VARCHAR2(120 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"USAGE_MEASUREMENT_BASIS" VARCHAR2(80 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"EVIDENCE" VARCHAR2(2000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"ACTIVE_YN" CHAR(1 BYTE) COLLATE "USING_NLS_COMP" DEFAULT ''Y'' NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
