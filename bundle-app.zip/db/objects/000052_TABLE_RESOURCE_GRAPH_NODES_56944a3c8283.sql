declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='RESOURCE_GRAPH_NODES' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,914,'CREATE TABLE "RESOURCE_GRAPH_NODES" ("SNAPSHOT_ID" NUMBER NOT NULL,"NODE_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"NODE_KIND" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"OCI_IDENTIFIER" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","DISPLAY_NAME" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","RESOURCE_TYPE" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP","CATEGORY" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","REGION" VARCHAR2(60 BYTE) COLLATE "USING_NLS_COMP","AVAILABILITY_DOMAIN" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","COMPARTMENT_ID" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","PARENT_COMPARTMENT_ID" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","LIFECYCLE_STATE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","TIME_CREATED" TIMESTAMP(6),"RAW_SOURCE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
