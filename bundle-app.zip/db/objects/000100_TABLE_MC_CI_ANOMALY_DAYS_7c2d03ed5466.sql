declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_CI_ANOMALY_DAYS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,404,'CREATE TABLE "MC_CI_ANOMALY_DAYS" ("REVIEW_ID" NUMBER NOT NULL,"SOURCE_DAY" DATE NOT NULL,"ACTUAL_AMOUNT" NUMBER NOT NULL,"REFERENCE_AMOUNT" NUMBER NOT NULL,"DELTA_AMOUNT" NUMBER NOT NULL,"NATIVE_PREDICTION" NUMBER NOT NULL,"NATIVE_SCORE" NUMBER NOT NULL,"DIRECTION" VARCHAR2(10 BYTE) COLLATE "USING_NLS_COMP" NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
