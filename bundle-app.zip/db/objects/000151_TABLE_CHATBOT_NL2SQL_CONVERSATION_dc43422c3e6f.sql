declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='CHATBOT_NL2SQL_CONVERSATION' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,690,'CREATE TABLE "CHATBOT_NL2SQL_CONVERSATION" ("CHAT_ID" NUMBER NOT NULL,"APP_USER" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP","FRIENDLY_NAME" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP","CREATED_AT" TIMESTAMP(6) DEFAULT SYSTIMESTAMP,"LAST_ACTIVITY" TIMESTAMP(6),"ARCHIVED_YN" VARCHAR2(1 BYTE) COLLATE "USING_NLS_COMP" DEFAULT ''N'',"OCI_CONVERSATION_ID" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP","MEMORY_SUBJECT_ID" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP","MEMORY_ACCESS_POLICY" VARCHAR2(64 BYTE) COLLATE "USING_NLS_COMP","UPDATED_AT" TIMESTAMP(6),"DATASET" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
