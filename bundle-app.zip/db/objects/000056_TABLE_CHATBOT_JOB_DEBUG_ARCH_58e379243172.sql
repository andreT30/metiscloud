declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='CHATBOT_JOB_DEBUG_ARCH' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,629,'CREATE TABLE "CHATBOT_JOB_DEBUG_ARCH" ("ID" NUMBER NOT NULL,"REQ_ID" VARCHAR2(32 BYTE) COLLATE "USING_NLS_COMP","LOG_ID" NUMBER,"CHAT_ID" NUMBER,"LEVEL_TXT" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","MESSAGE" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","PAYLOAD" CLOB COLLATE "USING_NLS_COMP","CREATED_AT" TIMESTAMP(6) WITH TIME ZONE,"ARCHIVED_AT" TIMESTAMP(6),"ARCHIVE_BATCH_ID" VARCHAR2(64 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("PAYLOAD") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 NOCACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
