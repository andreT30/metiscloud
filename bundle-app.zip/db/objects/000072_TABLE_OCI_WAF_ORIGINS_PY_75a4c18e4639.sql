declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_WAF_ORIGINS_PY' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,690,'CREATE TABLE "OCI_WAF_ORIGINS_PY" ("ORIGIN_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","WEB_APP_FIREWALL_POLICY_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","ORIGIN_NAME" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","URI" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","REGION" VARCHAR2(60 BYTE) COLLATE "USING_NLS_COMP","COMPARTMENT_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","RAW_JSON" CLOB COLLATE "USING_NLS_COMP","SNAPSHOT_TS" TIMESTAMP(6) DEFAULT SYSTIMESTAMP
      ) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("RAW_JSON") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 NOCACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
