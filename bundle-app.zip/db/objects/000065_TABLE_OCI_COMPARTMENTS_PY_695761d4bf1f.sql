declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_COMPARTMENTS_PY' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,638,'CREATE TABLE "OCI_COMPARTMENTS_PY" ("COMPARTMENT_ID" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","NAME" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","DESCRIPTION" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","LIFECYCLE_STATE" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","TIME_CREATED" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","PARENT_ID" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","PARENT" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","PATH" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","TENANCY_ID" VARCHAR2(2000 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
