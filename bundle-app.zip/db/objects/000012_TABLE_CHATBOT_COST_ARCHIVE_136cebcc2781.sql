declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='CHATBOT_COST_ARCHIVE' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,514,'CREATE TABLE "CHATBOT_COST_ARCHIVE" ("LOG_ID" NUMBER,"CHAT_ID" NUMBER,"MODEL_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","INPUT_TOKENS_TOTAL" NUMBER,"OUTPUT_TOKENS_TOTAL" NUMBER,"SNAPSHOT_REASON" VARCHAR2(12 BYTE) COLLATE "USING_NLS_COMP","SNAPSHOT_AT" TIMESTAMP(6) DEFAULT SYSTIMESTAMP,"APP_USER" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","STARTED_AT" TIMESTAMP(6),"INPUT_CHARS_TOTAL" NUMBER,"OUTPUT_CHARS_TOTAL" NUMBER) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
