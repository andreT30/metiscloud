
  ALTER TABLE "OCI_WORKLOADS" ADD CONSTRAINT "OCI_WORKLOADS_BUDGET_CK" CHECK (
        (budget_amount is null and budget_currency is null)
        or (budget_amount > 0 and regexp_like(budget_currency, '^[A-Z]{3}$'))
      ) ENABLE;