declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='APP_NOTIFICATION_BUDGET_ROUTES' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,405,'CREATE TABLE "APP_NOTIFICATION_BUDGET_ROUTES" ("RECIPIENT_USER" VARCHAR2(255 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"IS_ADMIN" CHAR(1 CHAR) COLLATE "USING_NLS_COMP" DEFAULT ''N'' NOT NULL,"WORKLOAD_NAME" VARCHAR2(100 CHAR) COLLATE "USING_NLS_COMP","LAST_SEEN_AT" TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
