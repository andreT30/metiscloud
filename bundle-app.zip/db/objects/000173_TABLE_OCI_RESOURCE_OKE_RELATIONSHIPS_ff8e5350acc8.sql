declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_RESOURCE_OKE_RELATIONSHIPS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,623,'CREATE TABLE "OCI_RESOURCE_OKE_RELATIONSHIPS" ("CHILD_DISPLAY_NAME" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","CHILD_RESOURCE_TYPE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","PARENT_DISPLAY_NAME" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","PARENT_RESOURCE_TYPE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","NODE_TYPE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","RAW_CLUSTER_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","NORMALIZED_CLUSTER_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","SNAPSHOT_DATE" DATE DEFAULT SYSDATE
) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
