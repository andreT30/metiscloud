declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_FOCUS_ARCHIVE_HASHES' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,195,'CREATE GLOBAL TEMPORARY TABLE "MC_FOCUS_ARCHIVE_HASHES" ("PHASE" CHAR(1 BYTE) COLLATE "USING_NLS_COMP","ROW_HASH" RAW(64),"COPIES" NUMBER) DEFAULT COLLATION "USING_NLS_COMP" ON COMMIT DELETE ROWS');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
