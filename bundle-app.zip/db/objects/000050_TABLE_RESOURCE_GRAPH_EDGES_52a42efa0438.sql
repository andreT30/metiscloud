declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='RESOURCE_GRAPH_EDGES' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,723,'CREATE TABLE "RESOURCE_GRAPH_EDGES" ("SNAPSHOT_ID" NUMBER NOT NULL,"EDGE_ID" VARCHAR2(2000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"SOURCE_NODE_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"TARGET_NODE_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"EDGE_TYPE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"EDGE_SUBTYPE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","PROVENANCE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"CONFIDENCE_SCORE" NUMBER(5,4),"IS_AUTHORITATIVE" VARCHAR2(1 BYTE) COLLATE "USING_NLS_COMP" DEFAULT ''N'' NOT NULL,"RAW_SOURCE_REF" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
