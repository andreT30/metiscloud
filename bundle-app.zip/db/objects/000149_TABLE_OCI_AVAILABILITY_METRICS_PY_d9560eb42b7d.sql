declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_AVAILABILITY_METRICS_PY' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,747,'CREATE TABLE "OCI_AVAILABILITY_METRICS_PY" ("RESOURCEDISPLAYNAME" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","TIMESTAMP" TIMESTAMP(6),"NAMESPACE" VARCHAR2(64 BYTE) COLLATE "USING_NLS_COMP","COMPARTMENT_ID" VARCHAR2(256 BYTE) COLLATE "USING_NLS_COMP","VALUE" NUMBER,"METRIC_NAME" VARCHAR2(128 BYTE) COLLATE "USING_NLS_COMP","RESOURCE_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","RESOURCE_TYPE" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP","REGION" VARCHAR2(60 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT PARTITION BY RANGE ("TIMESTAMP") INTERVAL (NUMTOYMINTERVAL(1, ''MONTH'')) (PARTITION "OCI_AVAILABILITY_METRICS_PY_BEFORE_2022" VALUES LESS THAN (TIMESTAMP ''2022-01-01 00:00:00''))');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
