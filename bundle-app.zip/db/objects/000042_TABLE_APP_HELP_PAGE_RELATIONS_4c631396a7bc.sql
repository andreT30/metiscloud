declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='APP_HELP_PAGE_RELATIONS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,817,'CREATE TABLE "APP_HELP_PAGE_RELATIONS" ("RELATION_CODE" VARCHAR2(100 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"APPLICATION_ID" NUMBER DEFAULT 1200 NOT NULL,"SOURCE_PAGE_ID" NUMBER NOT NULL,"TARGET_PAGE_ID" NUMBER NOT NULL,"TARGET_PAGE_TITLE" VARCHAR2(512 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"TOPIC_TERMS" VARCHAR2(2000 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"HANDOFF_TEXT" VARCHAR2(2000 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"PRIORITY" NUMBER DEFAULT 100 NOT NULL,"STATUS" VARCHAR2(20 CHAR) COLLATE "USING_NLS_COMP" DEFAULT ''PUBLISHED'' NOT NULL,"CREATED_AT" TIMESTAMP(6) DEFAULT systimestamp NOT NULL,"UPDATED_AT" TIMESTAMP(6) DEFAULT systimestamp NOT NULL,"TARGET_SECTION_HEADING" VARCHAR2(512 CHAR) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
