declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='RESOURCE_GRAPH_DOMAIN_CATALOG' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,681,'CREATE TABLE "RESOURCE_GRAPH_DOMAIN_CATALOG" ("DOMAIN_CODE" VARCHAR2(60 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"DISPLAY_NAME" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"DESCRIPTION" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","ENABLED_FLAG" VARCHAR2(1 BYTE) COLLATE "USING_NLS_COMP" DEFAULT ''Y'' NOT NULL,"DEFAULT_HOP_DEPTH" NUMBER DEFAULT 2 NOT NULL,"DEFAULT_MAX_NODES" NUMBER DEFAULT 120 NOT NULL,"COVERAGE_STATUS" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP" DEFAULT ''PLANNED'' NOT NULL,"SORT_ORDER" NUMBER DEFAULT 100 NOT NULL,"UPDATED_TS" TIMESTAMP(6) DEFAULT SYSTIMESTAMP NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
