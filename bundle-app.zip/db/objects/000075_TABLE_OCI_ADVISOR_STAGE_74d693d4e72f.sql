declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_ADVISOR_STAGE' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,374,'CREATE TABLE "OCI_ADVISOR_STAGE" ("RUN_ID" NUMBER NOT NULL,"ACTION_ID" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"PAYLOAD" CLOB COLLATE "USING_NLS_COMP" NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("PAYLOAD") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 CACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
