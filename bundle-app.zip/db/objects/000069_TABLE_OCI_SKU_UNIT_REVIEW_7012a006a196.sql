declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_SKU_UNIT_REVIEW' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,653,'CREATE TABLE "OCI_SKU_UNIT_REVIEW" ("PART_NUMBER" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"EXPECTED_CATALOG_METRIC" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"OBSERVED_BILLING_UNIT" VARCHAR2(400 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"DISCREPANCY_CODE" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"RESOLUTION_STATUS" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"EVIDENCE_NOTE" VARCHAR2(2000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"EVIDENCE_URL" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"REVIEWED_ON" DATE NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
