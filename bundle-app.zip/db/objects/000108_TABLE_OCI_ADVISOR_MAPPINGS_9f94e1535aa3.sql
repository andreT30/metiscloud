declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_ADVISOR_MAPPINGS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,788,'CREATE TABLE "OCI_ADVISOR_MAPPINGS" ("MAPPING_ID" NUMBER GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE NOORDER CACHE 20),"OPPORTUNITY_ID" NUMBER NOT NULL,"RUN_ID" NUMBER NOT NULL,"INVENTORY_AT" TIMESTAMP(6) WITH TIME ZONE,"MAPPING_STATE" VARCHAR2(20 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"WORKLOAD_NAMES" CLOB COLLATE "USING_NLS_COMP","RESOURCE_CONTEXT" CLOB COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("RESOURCE_CONTEXT") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 CACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) LOB ("WORKLOAD_NAMES") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 CACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
