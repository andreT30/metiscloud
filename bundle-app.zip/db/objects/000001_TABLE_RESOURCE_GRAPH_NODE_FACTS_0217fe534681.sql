declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='RESOURCE_GRAPH_NODE_FACTS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,669,'CREATE TABLE "RESOURCE_GRAPH_NODE_FACTS" ("SNAPSHOT_ID" NUMBER NOT NULL,"NODE_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"COST_7D" NUMBER(20,6),"COST_30D" NUMBER(20,6),"COST_90D" NUMBER(20,6),"USAGE_30D" NUMBER(20,6),"WORKLOAD_NAME" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","CREATED_BY" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","IMPLEMENTOR" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","ENVIRONMENT" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","COSTCENTER" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","HEALTH_SCORE" NUMBER(10,4),"LAST_METRIC_TS" TIMESTAMP(6)) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
