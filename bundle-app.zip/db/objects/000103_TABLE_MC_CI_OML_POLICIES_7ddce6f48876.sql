declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_CI_OML_POLICIES' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,607,'CREATE TABLE "MC_CI_OML_POLICIES" ("SCOPE_ID" NUMBER NOT NULL,"HORIZON" VARCHAR2(20 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"REVISION_NO" NUMBER NOT NULL,"METHOD_CODE" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"BRIDGE_FALLBACK" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP","EVIDENCE" CLOB COLLATE "USING_NLS_COMP" NOT NULL,"CONFIGURED_AT" TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("EVIDENCE") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 CACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
