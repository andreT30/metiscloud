declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='CHATBOT_PARAMETER_METADATA' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,825,'CREATE TABLE "CHATBOT_PARAMETER_METADATA" ("COMPONENT_TYPE" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"DESCRIPTION" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","PURPOSE" CLOB COLLATE "USING_NLS_COMP","CONSUMER_PACKAGE" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","DEFAULT_VALUE" CLOB COLLATE "USING_NLS_COMP","RISK_IF_CHANGED" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP" DEFAULT ''MEDIUM'',"CREATED_AT" TIMESTAMP(6) DEFAULT SYSTIMESTAMP,"UPDATED_AT" TIMESTAMP(6) DEFAULT SYSTIMESTAMP
   ) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("DEFAULT_VALUE") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 NOCACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) LOB ("PURPOSE") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 NOCACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
