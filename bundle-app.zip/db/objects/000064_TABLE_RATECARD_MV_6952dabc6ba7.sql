declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='RATECARD_MV' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,799,'CREATE TABLE "RATECARD_MV" ("REFRESH_BATCH_ID" RAW(16) NOT NULL,"RATECARD_LINE_KEY" VARCHAR2(64 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"IS_CURRENT" CHAR(1 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"BILLINGACCOUNTID" VARCHAR2(128 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"BILLINGCURRENCY" VARCHAR2(30 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"CHARGEDESCRIPTION" VARCHAR2(1000 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"PRICINGUNIT" VARCHAR2(400 CHAR) COLLATE "USING_NLS_COMP","SKUID" VARCHAR2(200 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"ACTUALUNITPRICE" NUMBER,"LISTUNITPRICE" NUMBER,"USAGE_QUANTITY" NUMBER,"EFFECTIVE_COST" NUMBER,"SOURCE_ROW_COUNT" NUMBER NOT NULL,"REFRESHED_AT" TIMESTAMP(6) WITH TIME ZONE NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
