declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_PRICE_DETAIL_STAGE' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,411,'CREATE GLOBAL TEMPORARY TABLE "OCI_PRICE_DETAIL_STAGE" ("PART_NUMBER" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"CURRENCY_CODE" VARCHAR2(10 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"PRICE_MODEL" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"TIER_ORDINAL" NUMBER NOT NULL,"UNIT_PRICE" NUMBER NOT NULL,"RANGE_MIN" NUMBER,"RANGE_MAX" NUMBER) DEFAULT COLLATION "USING_NLS_COMP" ON COMMIT DELETE ROWS');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
