declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='CREDIT_CONSUMPTION_STATE' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,600,'CREATE TABLE "CREDIT_CONSUMPTION_STATE" ("SUBSCRIPTION_ID" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","BILLINGACCOUNTID" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","ORDER_NUMBER" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","TIME_START" DATE,"TIME_END" DATE,"ORIGINAL_QUANTITY" NUMBER,"REMAINING_QUANTITY" NUMBER,"DEPLETED" BOOLEAN,"LAST_CONSUMED_AT" DATE,"ISO_CODE" VARCHAR2(10 BYTE) COLLATE "USING_NLS_COMP","LAST_UPDATED" DATE DEFAULT SYSDATE
,"SUBSCRIPTION_LINE_ID" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
