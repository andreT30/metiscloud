
  ALTER TABLE "MC_CI_CONTRIBUTIONS" ADD CONSTRAINT "MC_CI_CONTRIBUTIONS_ROWS_CK" CHECK (comparison_rows>=0 and observed_rows>=0 and comparison_rows+observed_rows>0) ENABLE;