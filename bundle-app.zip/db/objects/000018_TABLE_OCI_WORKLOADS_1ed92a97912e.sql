declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_WORKLOADS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,822,'CREATE TABLE "OCI_WORKLOADS" ("WORKLOAD_NAME" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"BUDGET_AMOUNT" NUMBER(18,2),"BUDGET_CURRENCY" VARCHAR2(3 CHAR) COLLATE "USING_NLS_COMP","VALUE" CLOB COLLATE "USING_NLS_COMP","SCOPE_MODE" VARCHAR2(20 CHAR) COLLATE "USING_NLS_COMP","SCOPE_SOURCE" CLOB COLLATE "USING_NLS_COMP","SCOPE_TENANCY_ID" VARCHAR2(2000 CHAR) COLLATE "USING_NLS_COMP","SCOPE_RESOLVED_AT" TIMESTAMP(6) WITH TIME ZONE,"SCOPE_ERROR" VARCHAR2(2000 CHAR) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("SCOPE_SOURCE") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 NOCACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) LOB ("VALUE") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 NOCACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
