declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_PRICE_CATALOG_RUN' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,801,'CREATE TABLE "OCI_PRICE_CATALOG_RUN" ("RUN_ID" NUMBER GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE NOORDER CACHE 20),"STARTED_AT" TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp NOT NULL,"FINISHED_AT" TIMESTAMP(6) WITH TIME ZONE,"STATUS" VARCHAR2(12 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"SOURCE_URL" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"SOURCE_LAST_UPDATED" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP","HTTP_STATUS" NUMBER,"RESPONSE_CHARS" NUMBER,"PRODUCT_COUNT" NUMBER,"PRICE_COUNT" NUMBER,"CURRENCY_COUNT" NUMBER,"COMPATIBILITY_COUNT" NUMBER,"ERROR_CODE" NUMBER,"ERROR_MESSAGE" VARCHAR2(2000 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
