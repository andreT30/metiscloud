
  ALTER TABLE "APP_EMAIL_QUEUE" ADD CONSTRAINT "APP_EMAIL_QUEUE_REPLY_TO_JSON_CK" CHECK (
          reply_to_json is null or reply_to_json is json
        ) ENABLE;