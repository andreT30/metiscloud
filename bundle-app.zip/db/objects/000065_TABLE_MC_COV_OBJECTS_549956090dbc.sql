declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_COV_OBJECTS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,647,'CREATE TABLE "MC_COV_OBJECTS" ("ATTEMPT_ID" NUMBER NOT NULL,"PHASE" VARCHAR2(6 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"OBJECT_IDENTITY" VARCHAR2(64 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"OBJECT_BYTES" NUMBER NOT NULL,"CHECKSUM" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"CREATED_AT" TIMESTAMP(6) NOT NULL,"MODIFIED_AT" TIMESTAMP(6) NOT NULL,"OPERATION_ID" NUMBER,"OPERATION_STATUS" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP","REJECTED_ROWS" NUMBER,"LOADED_ROWS" NUMBER,"STATUS" VARCHAR2(12 BYTE) COLLATE "USING_NLS_COMP" DEFAULT ''LISTED'' NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
