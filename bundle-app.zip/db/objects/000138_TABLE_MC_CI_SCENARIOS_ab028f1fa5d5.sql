declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_CI_SCENARIOS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,862,'CREATE TABLE "MC_CI_SCENARIOS" ("SCENARIO_ID" NUMBER GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE NOORDER CACHE 20),"BASELINE_RESULT_ID" NUMBER NOT NULL,"RUN_ID" NUMBER NOT NULL,"SCOPE_ID" NUMBER NOT NULL,"ACTOR_REALM_ID" NUMBER NOT NULL,"ACTOR_PRINCIPAL_ID" NUMBER NOT NULL,"ACTOR_REVISION" NUMBER NOT NULL,"START_DAY" DATE NOT NULL,"END_DAY" DATE NOT NULL,"PERCENT_ADJUSTMENT" NUMBER NOT NULL,"BASELINE_AMOUNT" NUMBER NOT NULL,"SCENARIO_AMOUNT" NUMBER NOT NULL,"ASSUMPTIONS" CLOB COLLATE "USING_NLS_COMP" NOT NULL,"CREATED_AT" TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("ASSUMPTIONS") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 CACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
