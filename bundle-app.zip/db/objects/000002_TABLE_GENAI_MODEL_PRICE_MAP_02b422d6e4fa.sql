declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='GENAI_MODEL_PRICE_MAP' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,392,'CREATE TABLE "GENAI_MODEL_PRICE_MAP" ("MODEL_KEY" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"PRICING_MODE" VARCHAR2(20 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"INPUT_PART_NUMBER" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"OUTPUT_PART_NUMBER" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
