
  ALTER TABLE "APP_PAGE_HELP_WIDGET_USAGE" ADD CONSTRAINT "APP_PAGE_HELP_WIDGET_USAGE_TOKENS_CK" CHECK (
          (input_tokens_total is null or input_tokens_total >= 0)
          and (output_tokens_total is null or output_tokens_total >= 0)
        ) ENABLE;