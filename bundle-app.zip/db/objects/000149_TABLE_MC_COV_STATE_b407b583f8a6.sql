declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_COV_STATE' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,358,'CREATE TABLE "MC_COV_STATE" ("STATE_ID" NUMBER NOT NULL,"REVISION" NUMBER DEFAULT 0 NOT NULL,"GENERATION_ID" NUMBER,"REASON" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP" DEFAULT ''NO_GENERATION'' NOT NULL,"UPDATED_AT" TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
