declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_LOAD_BALANCERS_PY' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,805,'CREATE TABLE "OCI_LOAD_BALANCERS_PY" ("LOAD_BALANCER_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","DISPLAY_NAME" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","SHAPE_NAME" VARCHAR2(512 BYTE) COLLATE "USING_NLS_COMP","LIFECYCLE_STATE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","IP_MODE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","IS_PRIVATE" VARCHAR2(10 BYTE) COLLATE "USING_NLS_COMP","REGION" VARCHAR2(60 BYTE) COLLATE "USING_NLS_COMP","COMPARTMENT_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","RAW_JSON" CLOB COLLATE "USING_NLS_COMP","SNAPSHOT_TS" TIMESTAMP(6) DEFAULT SYSTIMESTAMP
      ) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("RAW_JSON") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 NOCACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
