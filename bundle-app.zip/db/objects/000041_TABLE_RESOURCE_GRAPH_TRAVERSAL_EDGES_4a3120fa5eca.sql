declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='RESOURCE_GRAPH_TRAVERSAL_EDGES' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,709,'CREATE TABLE "RESOURCE_GRAPH_TRAVERSAL_EDGES" ("SNAPSHOT_ID" NUMBER NOT NULL,"SCOPE_NAME" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP" DEFAULT ''ROOT'' NOT NULL,"TENANCY_OCID" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","SOURCE_NODE_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"TARGET_NODE_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"EDGE_TYPE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"EDGE_SUBTYPE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","PROVENANCE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","RAW_SOURCE_REF" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","HOP" NUMBER NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
