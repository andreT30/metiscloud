
  ALTER TABLE "APP_PAGE_HELP_WIDGET_EVENTS" ADD CONSTRAINT "APP_PAGE_HELP_WIDGET_EVENTS_HTTP_CK" CHECK (
          http_status is null or (http_status between 100 and 599)
        ) ENABLE;