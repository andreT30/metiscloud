
  ALTER TABLE "MC_COST_INGESTION_STATE" ADD CONSTRAINT "MC_COST_IS_OWNER_CK" CHECK ((owner_kind is null and owner_run_id is null) or
   (owner_kind is not null and owner_kind in ('INITIAL','HISTORY') and owner_run_id is not null and owner_run_id>0 and owner_run_id=trunc(owner_run_id))) ENABLE;