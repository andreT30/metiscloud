
  ALTER TABLE "APP_EMAIL_QUEUE" ADD CONSTRAINT "APP_EMAIL_QUEUE_COUNTS_CK" CHECK (
          recipient_count between 1 and 50
          and attempt_count >= 0
          and max_attempts between 1 and 10
        ) ENABLE;