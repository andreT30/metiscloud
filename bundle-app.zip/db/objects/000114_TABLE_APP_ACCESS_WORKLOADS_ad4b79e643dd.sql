declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='APP_ACCESS_WORKLOADS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,324,'CREATE TABLE "APP_ACCESS_WORKLOADS" ("PRINCIPAL_ID" NUMBER NOT NULL,"WORKLOAD_NAME" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"ASSIGNED_BY" NUMBER NOT NULL,"ASSIGNED_AT" TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
