
  ALTER TABLE "CHATBOT_SEMANTIC_JOINS" ADD CONSTRAINT "CHATBOT_SEM_JOIN_CK_CARD" CHECK (cardinality IN ('one_to_one','one_to_many','many_to_one','many_to_many','unknown')) ENABLE;