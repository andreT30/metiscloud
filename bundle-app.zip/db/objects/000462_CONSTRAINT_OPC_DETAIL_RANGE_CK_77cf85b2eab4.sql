
  ALTER TABLE "OCI_PRICE_CATALOG_DETAIL" ADD CONSTRAINT "OPC_DETAIL_RANGE_CK" CHECK ((range_min is null and range_max is null) or
      (range_min is not null and range_max is not null and range_min>=0 and range_max>range_min)) ENABLE;