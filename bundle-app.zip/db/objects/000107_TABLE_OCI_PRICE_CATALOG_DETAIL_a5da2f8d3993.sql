declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_PRICE_CATALOG_DETAIL' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,457,'CREATE TABLE "OCI_PRICE_CATALOG_DETAIL" ("PART_NUMBER" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"CURRENCY_CODE" VARCHAR2(10 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"PRICE_MODEL" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"TIER_ORDINAL" NUMBER NOT NULL,"UNIT_PRICE" NUMBER NOT NULL,"RANGE_MIN" NUMBER,"RANGE_MAX" NUMBER,"REFRESH_RUN_ID" NUMBER NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
