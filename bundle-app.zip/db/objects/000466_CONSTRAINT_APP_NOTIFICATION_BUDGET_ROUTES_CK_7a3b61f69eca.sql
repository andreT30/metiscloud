
  ALTER TABLE "APP_NOTIFICATION_BUDGET_ROUTES" ADD CONSTRAINT "APP_NOTIFICATION_BUDGET_ROUTES_CK" CHECK (
          (is_admin = 'Y' and workload_name is null)
          or (is_admin = 'N' and workload_name is not null)
        ) ENABLE;