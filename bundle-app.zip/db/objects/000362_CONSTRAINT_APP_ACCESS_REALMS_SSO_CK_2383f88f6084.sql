
  ALTER TABLE "APP_ACCESS_REALMS" ADD CONSTRAINT "APP_ACCESS_REALMS_SSO_CK" CHECK (
  (provider_code='APEX_ACCOUNTS' and discovery_url is null and issuer is null) or
  (provider_code='OCI_SSO' and discovery_url is not null and issuer is not null)) ENABLE;