declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_JOB_RUNS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,742,'CREATE TABLE "OCI_JOB_RUNS" ("RUN_ID" NUMBER GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE NOORDER CACHE 20),"JOB_NAME" VARCHAR2(128 BYTE) COLLATE "USING_NLS_COMP","MODULE" VARCHAR2(128 BYTE) COLLATE "USING_NLS_COMP","START_TS" TIMESTAMP(6) DEFAULT systimestamp NOT NULL,"END_TS" TIMESTAMP(6),"STATUS" VARCHAR2(20 BYTE) COLLATE "USING_NLS_COMP","PARAMS_JSON" CLOB COLLATE "USING_NLS_COMP","ERROR_CODE" NUMBER,"ERROR_MSG" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("PARAMS_JSON") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 NOCACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
