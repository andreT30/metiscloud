declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_COV_CERTIFICATES' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,848,'CREATE TABLE "MC_COV_CERTIFICATES" ("CERTIFICATE_ID" NUMBER GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE NOORDER CACHE 20),"ATTEMPT_ID" NUMBER NOT NULL,"GENERATION_ID" NUMBER NOT NULL,"USAGE_DAY" DATE NOT NULL,"ACCOUNT_ID" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"CURRENCY" VARCHAR2(20 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"SOURCE_IDENTITY" VARCHAR2(64 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"TENANCY_ID" VARCHAR2(2000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"NORMALIZED_FINGERPRINT" VARCHAR2(64 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"NORMALIZED_ROWS" NUMBER NOT NULL,"NORMALIZED_COST" NUMBER NOT NULL,"OBSERVED_AT" TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
