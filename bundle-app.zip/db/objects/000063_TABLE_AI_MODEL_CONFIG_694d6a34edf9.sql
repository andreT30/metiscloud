declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='AI_MODEL_CONFIG' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,498,'CREATE TABLE "AI_MODEL_CONFIG" ("MODEL_ID" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","MODEL_NAME" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP","API_FORMAT" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP","IS_DEFAULT" VARCHAR2(1 BYTE) COLLATE "USING_NLS_COMP","REGION" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP","TEMPERATURE" NUMBER,"TOP_P" NUMBER,"TOP_K" NUMBER,"FREQUENCY_PENALTY" NUMBER,"PRESENCE_PENALTY" NUMBER) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
