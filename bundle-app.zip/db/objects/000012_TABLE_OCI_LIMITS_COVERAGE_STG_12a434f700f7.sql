declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_LIMITS_COVERAGE_STG' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,665,'CREATE TABLE "OCI_LIMITS_COVERAGE_STG" ("RUN_ID" NUMBER NOT NULL,"TENANCY_ID" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"SERVICE_NAME" VARCHAR2(128 BYTE) COLLATE "USING_NLS_COMP","REGION" VARCHAR2(128 BYTE) COLLATE "USING_NLS_COMP","SCOPE_TYPE" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP","AVAILABILITY_DOMAIN" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP","ATTEMPTED_AT" TIMESTAMP(6) WITH TIME ZONE NOT NULL,"SUCCESSFUL_AT" TIMESTAMP(6) WITH TIME ZONE,"OUTCOME" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"ERROR_CODE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
