declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_CI_DETECTION_POLICIES' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,419,'CREATE TABLE "MC_CI_DETECTION_POLICIES" ("SCOPE_ID" NUMBER NOT NULL,"REVISION_NO" NUMBER NOT NULL,"ABSOLUTE_THRESHOLD" NUMBER,"RELATIVE_THRESHOLD" NUMBER DEFAULT .30 NOT NULL,"NEAR_ZERO_THRESHOLD" NUMBER,"RECIPIENT_PRINCIPAL" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP","RECIPIENT_PROVIDER" VARCHAR2(20 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
