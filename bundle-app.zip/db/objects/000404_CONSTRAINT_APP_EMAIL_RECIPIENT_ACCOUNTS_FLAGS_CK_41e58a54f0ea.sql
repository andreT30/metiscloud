
  ALTER TABLE "APP_EMAIL_RECIPIENT_ACCOUNTS" ADD CONSTRAINT "APP_EMAIL_RECIPIENT_ACCOUNTS_FLAGS_CK" CHECK (
          operations_recipient in ('Y', 'N') and enabled in ('Y', 'N')
        ) ENABLE;