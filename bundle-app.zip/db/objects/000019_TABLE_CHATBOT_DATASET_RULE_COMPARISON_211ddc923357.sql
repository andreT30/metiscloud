declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='CHATBOT_DATASET_RULE_COMPARISON' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,635,'CREATE TABLE "CHATBOT_DATASET_RULE_COMPARISON" ("RULE_ID" NUMBER,"APPLIES_TO" VARCHAR2(40 BYTE) COLLATE "USING_NLS_COMP" DEFAULT ''PERIOD_COMPARISON'',"COMPARISON_TYPE" VARCHAR2(10 BYTE) COLLATE "USING_NLS_COMP","BASIS" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP","TIME_GRAIN" VARCHAR2(10 BYTE) COLLATE "USING_NLS_COMP","REQUIRES_TIME_SERIES_YN" CHAR(1 BYTE) COLLATE "USING_NLS_COMP" DEFAULT ''N'',"NOTES" VARCHAR2(2000 BYTE) COLLATE "USING_NLS_COMP","CREATED_AT" TIMESTAMP(6) DEFAULT SYSTIMESTAMP,"CREATED_BY" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
