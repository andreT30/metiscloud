declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_CATALOG_UNIT_RULE' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,695,'CREATE TABLE "OCI_CATALOG_UNIT_RULE" ("METRIC_NAME" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"RULE_ID" VARCHAR2(60 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"QUANTITY_KIND" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"BASE_UNIT" VARCHAR2(60 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"CATALOG_QUANTITY_SCALE" NUMBER NOT NULL,"CATALOG_TIME_BASIS" VARCHAR2(10 BYTE) COLLATE "USING_NLS_COMP","PERIOD_CONTEXT" VARCHAR2(40 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"EVIDENCE_NOTE" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"RULE_VERSION" VARCHAR2(20 BYTE) COLLATE "USING_NLS_COMP" NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
