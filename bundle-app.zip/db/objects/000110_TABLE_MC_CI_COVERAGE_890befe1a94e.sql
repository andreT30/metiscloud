declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_CI_COVERAGE' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,754,'CREATE TABLE "MC_CI_COVERAGE" ("RUN_ID" NUMBER NOT NULL,"SOURCE_DAY" DATE NOT NULL,"ACCOUNT_ID" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"CURRENCY" VARCHAR2(20 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"TENANCY_ID" VARCHAR2(2000 BYTE) COLLATE "USING_NLS_COMP","SOURCE_RUN_ID" NUMBER,"STATE" VARCHAR2(10 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"REASON" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"OBSERVED_ROWS" NUMBER NOT NULL,"OBSERVED_COST" NUMBER NOT NULL,"EXPECTED_FILES" NUMBER,"LOADED_FILES" NUMBER,"FAILED_FILES" NUMBER,"POSTPROCESSING_STATE" VARCHAR2(20 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"CERTIFICATE_ID" NUMBER,"GENERATION_ID" NUMBER) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
