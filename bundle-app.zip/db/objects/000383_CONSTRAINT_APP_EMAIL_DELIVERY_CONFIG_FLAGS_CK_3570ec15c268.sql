
  ALTER TABLE "APP_EMAIL_DELIVERY_CONFIG" ADD CONSTRAINT "APP_EMAIL_DELIVERY_CONFIG_FLAGS_CK" CHECK (
          enabled in ('Y', 'N')
          and export_emails_enabled in ('Y', 'N')
          and budget_emails_enabled in ('Y', 'N')
          and job_failure_emails_enabled in ('Y', 'N')
        ) ENABLE;