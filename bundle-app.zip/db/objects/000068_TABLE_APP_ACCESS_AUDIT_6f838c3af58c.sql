declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='APP_ACCESS_AUDIT' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,854,'CREATE TABLE "APP_ACCESS_AUDIT" ("AUDIT_ID" NUMBER GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE NOORDER CACHE 20),"REALM_ID" NUMBER NOT NULL,"ACTOR_ID" NUMBER,"SUBJECT_ID" NUMBER,"EVENT_CODE" VARCHAR2(40 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"BEFORE_STATE" CLOB COLLATE "USING_NLS_COMP","AFTER_STATE" CLOB COLLATE "USING_NLS_COMP","CORRELATION_ID" RAW(16) DEFAULT sys_guid() NOT NULL,"OCCURRED_AT" TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("AFTER_STATE") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 CACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) LOB ("BEFORE_STATE") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 CACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
