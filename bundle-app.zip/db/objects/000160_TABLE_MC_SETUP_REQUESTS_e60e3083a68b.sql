declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_SETUP_REQUESTS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,471,'CREATE TABLE "MC_SETUP_REQUESTS" ("REQUEST_ID" VARCHAR2(64 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"ACTOR" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"ACTION" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"REQUEST_HASH" VARCHAR2(64 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"REVISION" NUMBER NOT NULL,"CREATED_AT" TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
