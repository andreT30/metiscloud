declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_PRICE_CATALOG' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,897,'CREATE TABLE "OCI_PRICE_CATALOG" ("PART_NUMBER" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"DISPLAY_NAME" VARCHAR2(400 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"METRIC_NAME" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"SERVICE_CATEGORY" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"CURRENCY_CODE" VARCHAR2(10 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"PRICE_MODEL" VARCHAR2(50 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"UNIT_PRICE" NUMBER NOT NULL,"FETCHED_AT" TIMESTAMP(6) DEFAULT systimestamp NOT NULL,"SRC_URL" VARCHAR2(1000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"TIER_COUNT" NUMBER,"SELECTED_RANGE_MIN" NUMBER,"SELECTED_RANGE_MAX" NUMBER,"SELECTION_POLICY" VARCHAR2(40 BYTE) COLLATE "USING_NLS_COMP","REFRESH_RUN_ID" NUMBER,"CATALOG_STATUS" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
