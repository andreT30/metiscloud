declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_CI_OML_HORIZONS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,825,'CREATE TABLE "MC_CI_OML_HORIZONS" ("RUN_ID" NUMBER NOT NULL,"SCOPE_ID" NUMBER NOT NULL,"HORIZON" VARCHAR2(20 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"POLICY_REVISION" NUMBER NOT NULL,"POLICY_EVIDENCE" CLOB COLLATE "USING_NLS_COMP" NOT NULL,"CONFIGURED_METHOD" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"SELECTED_METHOD" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"SELECTION_REASON" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"ISSUANCE_DAY" DATE NOT NULL,"TARGET_FROM" DATE NOT NULL,"TARGET_TO" DATE NOT NULL,"STATE" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"METHOD_ID" NUMBER) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("POLICY_EVIDENCE") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 CACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
