declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='APP_ACCESS_PENDING' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,546,'CREATE TABLE "APP_ACCESS_PENDING" ("PENDING_ID" NUMBER GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE NOORDER CACHE 20),"REALM_ID" NUMBER NOT NULL,"PROVIDER_SUBJECT" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"SUBJECT_KEY" RAW(32) NOT NULL,"REVISION" NUMBER(15,0) DEFAULT 1 NOT NULL,"CREATED_BY" NUMBER NOT NULL,"CREATED_AT" TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
