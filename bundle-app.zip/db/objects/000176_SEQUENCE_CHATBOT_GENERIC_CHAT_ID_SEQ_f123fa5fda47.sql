declare target_min number; target_max number; unsupported_count number; statement_sql varchar2(32767);
begin
  begin select min_value,max_value into target_min,target_max from user_sequences where sequence_name='CHATBOT_GENERIC_CHAT_ID_SEQ';
  exception when no_data_found then execute immediate 'CREATE SEQUENCE "CHATBOT_GENERIC_CHAT_ID_SEQ" MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOKEEP INCREMENT BY 1 NOCYCLE NOORDER CACHE 100'; return; end;
  select count(*) into unsupported_count from user_sequences where sequence_name='CHATBOT_GENERIC_CHAT_ID_SEQ' and (nvl(scale_flag,'?')<>'N' or nvl(extend_flag,'?')<>'N' or nvl(sharded_flag,'?')<>'N' or nvl(session_flag,'?')<>'N');
  if unsupported_count<>0 then raise_application_error(-20865,'Incompatible target sequence mode; no sequence DDL applied'); end if;
  statement_sql:='ALTER SEQUENCE "CHATBOT_GENERIC_CHAT_ID_SEQ" NOKEEP INCREMENT BY 1 NOCYCLE NOORDER CACHE 100';
  if target_min<>1 then statement_sql:=statement_sql||' MINVALUE 1'; end if;
  if target_max<>9999999999999999999999999999 then statement_sql:=statement_sql||' MAXVALUE 9999999999999999999999999999'; end if;
  execute immediate statement_sql;
end;
/
