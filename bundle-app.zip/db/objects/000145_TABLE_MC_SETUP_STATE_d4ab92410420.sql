declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_SETUP_STATE' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,799,'CREATE TABLE "MC_SETUP_STATE" ("SETUP_ID" NUMBER NOT NULL,"REVISION" NUMBER DEFAULT 0 NOT NULL,"STATE" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP" DEFAULT ''DRAFT'' NOT NULL,"PROFILE_JSON" CLOB COLLATE "USING_NLS_COMP","CONFIG_HASH" VARCHAR2(64 BYTE) COLLATE "USING_NLS_COMP","CHECKS_JSON" CLOB COLLATE "USING_NLS_COMP","INITIAL_LOAD_RUN_ID" NUMBER,"ACTOR" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP","UPDATED_AT" TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp NOT NULL) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("CHECKS_JSON") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 NOCACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) LOB ("PROFILE_JSON") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 NOCACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
