declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_CI_OML_BUILDS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,464,'CREATE TABLE "MC_CI_OML_BUILDS" ("MODEL_NAME" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"INVOCATION_TOKEN" RAW(16) NOT NULL,"METHOD_ID" NUMBER NOT NULL,"STATE" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"STARTED_AT" TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp NOT NULL,"FINISHED_AT" TIMESTAMP(6) WITH TIME ZONE,"FAILURE_CODE" NUMBER,"CLEANUP_CODE" NUMBER) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
