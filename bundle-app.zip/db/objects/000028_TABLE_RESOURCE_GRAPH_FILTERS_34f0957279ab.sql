declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='RESOURCE_GRAPH_FILTERS' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,370,'CREATE TABLE "RESOURCE_GRAPH_FILTERS" ("SNAPSHOT_ID" NUMBER NOT NULL,"FILTER_TYPE" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"FILTER_VALUE" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP" NOT NULL,"FILTER_LABEL" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","SORT_ORDER" NUMBER) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
