declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='APP_EMAIL_TEMPLATES' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,794,'CREATE TABLE "APP_EMAIL_TEMPLATES" ("EVENT_TYPE" VARCHAR2(30 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"SUBJECT_TEMPLATE" VARCHAR2(998 CHAR) COLLATE "USING_NLS_COMP" NOT NULL,"BODY_TEXT_TEMPLATE" CLOB COLLATE "USING_NLS_COMP" NOT NULL,"BODY_HTML_TEMPLATE" CLOB COLLATE "USING_NLS_COMP","VERSION_NO" NUMBER DEFAULT 1 NOT NULL,"UPDATED_AT" TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp NOT NULL,"UPDATED_BY" VARCHAR2(255 CHAR) COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("BODY_HTML_TEMPLATE") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 NOCACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) LOB ("BODY_TEXT_TEMPLATE") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 NOCACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
