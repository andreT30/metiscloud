declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='CREDIT_USAGE_AGG' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,284,'CREATE TABLE "CREDIT_USAGE_AGG" ("BILLINGACCOUNTID" VARCHAR2(100 BYTE) COLLATE "USING_NLS_COMP","CHARGEPERIODEND" DATE,"BILLEDCOST" NUMBER,"HOURLY_COST" NUMBER,"INSERTED_AT" DATE DEFAULT SYSDATE
   ) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
