declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='MC_CI_DELIVERY_POLICIES' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,732,'CREATE TABLE "MC_CI_DELIVERY_POLICIES" ("SCOPE_ID" NUMBER NOT NULL,"ENABLED" CHAR(1 BYTE) COLLATE "USING_NLS_COMP" DEFAULT ''N'' NOT NULL,"POLICY_REVISION" NUMBER NOT NULL,"ACCEPTED_RUN_ID" NUMBER,"SHADOW_COMPLETE_DAYS" NUMBER,"FALSE_ALERTS_PER_100" NUMBER,"REVIEWED_PRECISION" NUMBER,"REVIEWED_FINDINGS" NUMBER,"EVIDENCE_PROVENANCE" VARCHAR2(30 BYTE) COLLATE "USING_NLS_COMP","ACCEPTED_BY" VARCHAR2(255 BYTE) COLLATE "USING_NLS_COMP","ACCEPTED_AT" TIMESTAMP(6) WITH TIME ZONE,"REVIEW_EVIDENCE" CLOB COLLATE "USING_NLS_COMP") DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("REVIEW_EVIDENCE") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 CACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
