declare statement_sql clob; n number; begin
select count(*) into n from user_objects where object_name='OCI_JOB_RUN_LOG' and namespace=1;
if n<>0 then raise_application_error(-20865,'Existing target name blocks CREATE-only table payload; no table changes applied'); end if;
dbms_lob.createtemporary(statement_sql,true);
dbms_lob.writeappend(statement_sql,721,'CREATE TABLE "OCI_JOB_RUN_LOG" ("LOG_ID" NUMBER GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE NOORDER CACHE 20),"RUN_ID" NUMBER NOT NULL,"LOG_TS" TIMESTAMP(6) DEFAULT systimestamp NOT NULL,"LEVEL_NAME" VARCHAR2(10 BYTE) COLLATE "USING_NLS_COMP","STEP_NAME" VARCHAR2(200 BYTE) COLLATE "USING_NLS_COMP","MESSAGE" VARCHAR2(4000 BYTE) COLLATE "USING_NLS_COMP","DETAILS_JSON" CLOB COLLATE "USING_NLS_COMP","ROWS_AFFECTED" NUMBER,"ELAPSED_MS" NUMBER) DEFAULT COLLATION "USING_NLS_COMP" NOROWDEPENDENCIES DISABLE ROW MOVEMENT LOB ("DETAILS_JSON") STORE AS SECUREFILE (ENABLE STORAGE IN ROW 4000 NOCACHE LOGGING NOCOMPRESS KEEP_DUPLICATES RETENTION) READ WRITE');
execute immediate statement_sql; dbms_lob.freetemporary(statement_sql);
exception when others then if dbms_lob.istemporary(statement_sql)=1 then dbms_lob.freetemporary(statement_sql); end if; raise; end;
/
