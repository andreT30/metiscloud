
  ALTER TABLE "MC_SETUP_HISTORY_RUNS" ADD CONSTRAINT "MC_SETUP_HR_DATES_CK" CHECK (start_date=trunc(start_date) and end_date=trunc(end_date) and start_date<=end_date) ENABLE;